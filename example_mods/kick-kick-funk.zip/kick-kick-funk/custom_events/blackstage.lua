function onEvent(name, value1)
	if name == 'blackstage' and value1 == 'a' then
		makeLuaSprite('blackbg', '', -500, -300)
		makeGraphic('blackbg',5000,5000,'000000')
		addLuaSprite('blackbg', true)
	end
	if name == 'blackstage' and value1 == 'b' then
		removeLuaSprite('blackbg')
	end
end